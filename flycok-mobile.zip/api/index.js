import axios from 'axios';
import { API_URL } from '../config';

// Default headers
axios.defaults.headers.post['Content-Type'] = 'application/json';

// Request interceptor for API calls
axios.interceptors.request.use(
  async config => {
    return config;
  },
  error => {
    Promise.reject(error)
  });

// Response interceptor for API calls
axios.interceptors.response.use(
  (response) => {
    return response;
  },
  async function (error) {
    const originalRequest = error.config;
    
    // Handle session timeout or auth errors
    if (error.response.status === 401 && !originalRequest._retry) {
      // This could be a place to implement token refresh logic
      return Promise.reject(error);
    }
    
    return Promise.reject(error);
  }
);

// User API calls
export const userApi = {
  login: (credentials) => axios.post(`${API_URL}/api/login`, credentials),
  register: (userData) => axios.post(`${API_URL}/api/register`, userData),
  logout: () => axios.post(`${API_URL}/api/logout`),
  getProfile: () => axios.get(`${API_URL}/api/user`),
  updateProfile: (data) => axios.patch(`${API_URL}/api/user`, data),
  resetPassword: (data) => axios.post(`${API_URL}/api/reset-password`, data),
};

// Video call API
export const videoApi = {
  getToken: (roomName) => axios.post(`${API_URL}/api/video/token`, { roomName }),
  endCall: (roomName) => axios.post(`${API_URL}/api/video/end-call`, { roomName }),
};

// Live stream API
export const streamApi = {
  getLiveStreamers: (params) => axios.get(`${API_URL}/api/live-streamers`, { params }),
  startStream: () => axios.post(`${API_URL}/api/start-stream`),
  endStream: () => axios.post(`${API_URL}/api/end-stream`),
  sendGift: (data) => axios.post(`${API_URL}/api/send-gift`, data),
};

// Chat API
export const chatApi = {
  getConversations: () => axios.get(`${API_URL}/api/conversations`),
  getMessages: (conversationId) => axios.get(`${API_URL}/api/messages/${conversationId}`),
  sendMessage: (data) => axios.post(`${API_URL}/api/messages`, data),
};

// Membership API
export const membershipApi = {
  getPlans: () => axios.get(`${API_URL}/api/membership/plans`),
  subscribe: (planId) => axios.post(`${API_URL}/api/membership/subscribe`, { planId }),
};