import React, { createContext, useState, useContext, useEffect } from 'react';
import { Appearance } from 'react-native';
import { COLORS } from '../config';

const ThemeContext = createContext();

export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider = ({ children }) => {
  const [isDarkMode, setIsDarkMode] = useState(true); // Default to dark mode for Neşgi app
  const [theme, setTheme] = useState({
    ...COLORS,
    mode: 'dark'
  });

  // Listen for system theme changes, but we prefer dark mode by default
  useEffect(() => {
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      // Only update if user has chosen system theme (we could add this option in settings)
      // For now, we'll keep dark mode as default
      console.log('System theme changed to:', colorScheme);
    });

    return () => subscription.remove();
  }, []);

  const toggleTheme = () => {
    setIsDarkMode(prev => !prev);
    setTheme({
      ...COLORS,
      mode: isDarkMode ? 'light' : 'dark',
      background: isDarkMode ? '#FFFFFF' : '#000000',
      text: isDarkMode ? '#000000' : '#FFFFFF',
      card: isDarkMode ? '#F5F5F5' : '#111111',
      border: isDarkMode ? '#E0E0E0' : '#333333',
    });
  };

  return (
    <ThemeContext.Provider value={{
      isDarkMode,
      theme,
      toggleTheme
    }}>
      {children}
    </ThemeContext.Provider>
  );
};