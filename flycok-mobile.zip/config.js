// Development vs Production API URL
export const API_URL = __DEV__ 
  ? 'http://192.168.1.X:5000' // Development IP - replace X with your local IP
  : 'https://api.flycok.com'; // Production URL

// Theme colors
export const COLORS = {
  primary: '#A5243D', // Wine red (Flycok brand color)
  secondary: '#FFA500', // Orange
  background: '#000000', // Black
  card: '#111111',
  text: '#FFFFFF',
  border: '#333333',
  notification: '#FF3B30',
};

// App constants
export const APP_CONSTANTS = {
  appName: 'Flycok',
  company: '30 N Gould St, Ste 40542, Sheridan, WY 82801',
  supportEmail: 'support@flycok.com',
  version: '1.0.0',
};