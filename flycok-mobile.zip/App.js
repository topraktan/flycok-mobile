import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// Auth Screens
import LoginScreen from './screens/auth/LoginScreen';
import RegisterScreen from './screens/auth/RegisterScreen';
import ForgotPasswordScreen from './screens/auth/ForgotPasswordScreen';

// Main App Screens
import TabNavigator from './navigation/TabNavigator';
import ProfileScreen from './screens/main/ProfileScreen';
import ChatScreen from './screens/chat/ChatScreen';
import VideoCallScreen from './screens/video/VideoCallScreen';
import LiveStreamScreen from './screens/live/LiveStreamScreen';
import SettingsScreen from './screens/main/SettingsScreen';
import VipMembershipScreen from './screens/main/VipMembershipScreen';

// Contexts and Providers
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';

const Stack = createNativeStackNavigator();
const queryClient = new QueryClient();

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="auto" />
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <AuthProvider>
            <NavigationContainer>
              <Stack.Navigator 
                initialRouteName="Login"
                screenOptions={{
                  headerStyle: {
                    backgroundColor: '#8B0000', // Wine red color
                  },
                  headerTintColor: '#fff',
                  headerTitleStyle: {
                    fontWeight: 'bold',
                  },
                }}
              >
                {/* Auth Screens */}
                <Stack.Screen 
                  name="Login" 
                  component={LoginScreen} 
                  options={{ title: 'Neşgi - Giriş' }} 
                />
                <Stack.Screen 
                  name="Register" 
                  component={RegisterScreen} 
                  options={{ title: 'Yeni Hesap Oluştur' }} 
                />
                <Stack.Screen 
                  name="ForgotPassword" 
                  component={ForgotPasswordScreen} 
                  options={{ title: 'Şifremi Unuttum' }} 
                />
                
                {/* Main App Navigation */}
                <Stack.Screen 
                  name="Main" 
                  component={TabNavigator} 
                  options={{ headerShown: false }} 
                />
                
                {/* Other Screens */}
                <Stack.Screen name="Profile" component={ProfileScreen} />
                <Stack.Screen name="Chat" component={ChatScreen} />
                <Stack.Screen 
                  name="VideoCall" 
                  component={VideoCallScreen} 
                  options={{ headerShown: false }}
                />
                <Stack.Screen 
                  name="LiveStream" 
                  component={LiveStreamScreen} 
                  options={{ headerShown: false }}
                />
                <Stack.Screen name="Settings" component={SettingsScreen} />
                <Stack.Screen 
                  name="VipMembership" 
                  component={VipMembershipScreen} 
                  options={{ title: 'VIP Üyelik' }}
                />
              </Stack.Navigator>
            </NavigationContainer>
          </AuthProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}