# Neşgi Mobile

Bu repo, Neşgi sosyal ağ platformunun React Native/Expo ile geliştirilmiş mobil uygulamasını içerir.

## Özellikler

- Kimlik doğrulama (giriş, kayıt, şifre sıfırlama)
- Canlı yayın izleme
- Video görüşmeleri
- Anlık mesajlaşma
- Kullanıcı profilleri
- VIP üyelik
- Çeşitli dil desteği
- Konum bazlı içerik

## Başlangıç

Bu projeyi yerel geliştirme ortamınızda çalıştırmak için aşağıdaki adımları izleyin:

```bash
# Depoyu klonlayın
git clone https://github.com/kullaniciadi/nesgi-mobile.git

# Proje dizinine gidin
cd nesgi-mobile

# Bağımlılıkları yükleyin
npm install

# Uygulamayı başlatın
npm start
```

## API Bağlantısı

Uygulama, Neşgi web uygulamasının API'sine bağlanır. API URL'sini `config.js` dosyasında ayarlayabilirsiniz:

```javascript
export const API_URL = __DEV__ 
  ? 'http://192.168.1.X:5000' // Geliştirme IP'si - X'i yerel IP'nizle değiştirin
  : 'https://api.nesgi.com'; // Üretim URL'si
```

## Mobil Geliştirme Gereksinimleri

- Node.js (>= 14.0.0)
- npm veya yarn
- Expo CLI (`npm install -g expo-cli`)
- iOS için: macOS ve Xcode
- Android için: Android Studio ve Android SDK

## Twilio Video Entegrasyonu

Video aramaları için Twilio SDK'sı kullanılmaktadır. Twilio API kimlik bilgilerini projenin ana dizininde bir `.env` dosyasında sağlayın:

```
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_API_KEY=your_api_key
TWILIO_API_SECRET=your_api_secret
```

## Lisans

Bu proje [MIT Lisansı](LICENSE) altında lisanslanmıştır.