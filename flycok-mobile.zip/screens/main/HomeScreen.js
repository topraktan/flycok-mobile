import React, { useState, useEffect } from 'react';
import { 
  StyleSheet, 
  View, 
  Text, 
  FlatList, 
  TouchableOpacity, 
  Image, 
  ActivityIndicator,
  RefreshControl 
} from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { streamApi } from '../../api';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../../config';
import { useAuth } from '../../context/AuthContext';

export default function HomeScreen({ navigation }) {
  const { user } = useAuth();
  const [refreshing, setRefreshing] = useState(false);

  const { 
    data: liveStreamers, 
    isLoading, 
    error, 
    refetch 
  } = useQuery({
    queryKey: ['liveStreamers'],
    queryFn: () => streamApi.getLiveStreamers().then(res => res.data),
  });

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  const handleStreamPress = (streamerId) => {
    navigation.navigate('LiveStream', { streamerId });
  };

  if (isLoading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Ionicons name="alert-circle-outline" size={60} color={COLORS.secondary} />
        <Text style={styles.errorText}>Yayınlar yüklenirken bir hata oluştu</Text>
        <TouchableOpacity style={styles.retryButton} onPress={refetch}>
          <Text style={styles.retryButtonText}>Tekrar Dene</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Render header with welcome message
  const renderHeader = () => (
    <View style={styles.headerContainer}>
      <Text style={styles.welcomeText}>
        Hoş Geldin, {user?.username || 'Misafir'}!
      </Text>
      <Text style={styles.subtitleText}>
        Canlı yayınlar ve görüntülü sohbetler seni bekliyor
      </Text>
    </View>
  );

  // Render empty state if no live streamers
  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Ionicons name="videocam-off-outline" size={80} color="#555" />
      <Text style={styles.emptyText}>Şu anda aktif yayın bulunmamaktadır</Text>
      <Text style={styles.emptySubText}>Daha sonra tekrar kontrol edin veya keşfetmeye başlayın</Text>
      <TouchableOpacity 
        style={styles.discoverButton} 
        onPress={() => navigation.navigate('Discover')}
      >
        <Text style={styles.discoverButtonText}>Keşfet</Text>
      </TouchableOpacity>
    </View>
  );

  // Render each live streamer card
  const renderStreamerCard = ({ item }) => (
    <TouchableOpacity
      style={styles.streamerCard}
      onPress={() => handleStreamPress(item.id)}
    >
      <View style={styles.thumbnailContainer}>
        <Image source={{ uri: item.thumbnailUrl || item.profileImage }} style={styles.thumbnail} />
        <View style={styles.liveIndicator}>
          <Text style={styles.liveText}>CANLI</Text>
        </View>
        <View style={styles.viewersContainer}>
          <Ionicons name="eye-outline" size={16} color="#fff" />
          <Text style={styles.viewersText}>{item.viewerCount || 0}</Text>
        </View>
      </View>
      <View style={styles.streamerInfo}>
        <Image source={{ uri: item.profileImage }} style={styles.streamerAvatar} />
        <View style={styles.streamerDetails}>
          <Text style={styles.streamerName} numberOfLines={1}>{item.username}</Text>
          <Text style={styles.streamTitle} numberOfLines={1}>{item.streamTitle || 'Canlı Yayın'}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        ListHeaderComponent={renderHeader}
        data={liveStreamers}
        renderItem={renderStreamerCard}
        keyExtractor={(item) => item.id.toString()}
        ListEmptyComponent={renderEmpty}
        numColumns={2}
        columnWrapperStyle={styles.streamRow}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[COLORS.primary]}
            tintColor={COLORS.primary}
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.background,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    padding: 20,
  },
  errorText: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: COLORS.primary,
    padding: 12,
    borderRadius: 8,
    minWidth: 120,
    alignItems: 'center',
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  headerContainer: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#222',
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  subtitleText: {
    fontSize: 14,
    color: '#999',
  },
  listContent: {
    paddingBottom: 20,
  },
  streamRow: {
    justifyContent: 'space-between',
    paddingHorizontal: 10,
  },
  streamerCard: {
    width: '48%',
    marginTop: 15,
    backgroundColor: '#111',
    borderRadius: 10,
    overflow: 'hidden',
  },
  thumbnailContainer: {
    position: 'relative',
    aspectRatio: 16 / 9,
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  liveIndicator: {
    position: 'absolute',
    top: 10,
    left: 10,
    backgroundColor: 'red',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  liveText: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold',
  },
  viewersContainer: {
    position: 'absolute',
    bottom: 10,
    right: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 4,
  },
  viewersText: {
    color: 'white',
    fontSize: 12,
    marginLeft: 4,
  },
  streamerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
  },
  streamerAvatar: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginRight: 10,
  },
  streamerDetails: {
    flex: 1,
  },
  streamerName: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  streamTitle: {
    color: '#999',
    fontSize: 12,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    textAlign: 'center',
  },
  emptySubText: {
    color: '#999',
    fontSize: 14,
    textAlign: 'center',
    marginTop: 10,
    marginBottom: 30,
  },
  discoverButton: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  discoverButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});