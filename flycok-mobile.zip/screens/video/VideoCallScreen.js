import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Alert,
  Platform,
  StatusBar
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { videoApi } from '../../api';
import { COLORS } from '../../config';
import { useMutation } from '@tanstack/react-query';
import { Camera } from 'expo-camera';

// Import TwilioVideo when we have the native module
// import TwilioVideo from 'twilio-video-react-native';

export default function VideoCallScreen({ navigation, route }) {
  const { user } = useAuth();
  const { calleeId, calleeName, calleeImage } = route.params || {};
  
  const [hasPermission, setHasPermission] = useState(null);
  const [isFrontCamera, setIsFrontCamera] = useState(true);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isCallConnected, setIsCallConnected] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  
  const cameraRef = useRef(null);
  const timerRef = useRef(null);

  // Request token mutation
  const { mutate: getToken, isLoading: isLoadingToken } = useMutation({
    mutationFn: () => videoApi.getToken(`room-${user.id}-${calleeId}`),
    onSuccess: (response) => {
      const { token, roomName } = response.data;
      // Connect to Twilio Video room with token
      // This would be implemented with twilio-video-react-native in production
      console.log('Successfully got token, would connect to:', roomName);
      
      // Simulate successful connection for demo
      setTimeout(() => {
        setIsCallConnected(true);
        startTimer();
      }, 1500);
    },
    onError: (error) => {
      console.error('Failed to get token:', error);
      Alert.alert(
        'Bağlantı Hatası',
        'Video araması başlatılamadı. Lütfen daha sonra tekrar deneyin.',
        [{ text: 'Tamam', onPress: () => navigation.goBack() }]
      );
    }
  });

  // Request camera/mic permissions
  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      const micPermission = await Camera.requestMicrophonePermissionsAsync();
      setHasPermission(status === 'granted' && micPermission.status === 'granted');
      
      if (status !== 'granted' || micPermission.status !== 'granted') {
        Alert.alert(
          'İzin Gerekli',
          'Video araması için kamera ve mikrofon izinleri gereklidir.',
          [{ text: 'Tamam', onPress: () => navigation.goBack() }]
        );
      } else {
        // Auto-start call when permissions are granted
        getToken();
      }
    })();
    
    // Cleanup on unmount
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const startTimer = () => {
    timerRef.current = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
  };

  const formatDuration = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const toggleCamera = () => {
    setIsFrontCamera(!isFrontCamera);
  };

  const toggleMic = () => {
    setIsMicMuted(!isMicMuted);
  };

  const toggleVideo = () => {
    setIsVideoEnabled(!isVideoEnabled);
  };

  const endCall = () => {
    // Clean up Twilio room connection
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    // Notify API call has ended
    videoApi.endCall(`room-${user.id}-${calleeId}`)
      .catch(error => console.error('Error ending call:', error));
      
    navigation.goBack();
  };

  // If we don't have permissions yet, show a loading view
  if (hasPermission === null || isLoadingToken) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Bağlanıyor...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#000000" />
      
      {/* Camera Preview */}
      {hasPermission && (
        <Camera
          ref={cameraRef}
          style={isVideoEnabled ? styles.camera : styles.disabledCamera}
          type={isFrontCamera ? Camera.Constants.Type.front : Camera.Constants.Type.back}
          ratio="16:9"
        />
      )}
      
      {/* Disabled video overlay */}
      {!isVideoEnabled && (
        <View style={styles.disabledVideoOverlay}>
          <Ionicons name="videocam-off" size={60} color="#fff" />
          <Text style={styles.disabledVideoText}>Video kapalı</Text>
        </View>
      )}
      
      {/* Call info bar */}
      <View style={styles.callInfoBar}>
        <Text style={styles.calleeName}>{calleeName || 'Kullanıcı'}</Text>
        {isCallConnected && (
          <Text style={styles.callDuration}>{formatDuration(callDuration)}</Text>
        )}
        {!isCallConnected && <Text style={styles.callStatus}>Bağlanıyor...</Text>}
      </View>
      
      {/* Control buttons */}
      <View style={styles.controlsContainer}>
        <TouchableOpacity style={styles.controlButton} onPress={toggleCamera}>
          <Ionicons name="camera-reverse-outline" size={24} color="#fff" />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.controlButton} onPress={toggleMic}>
          <Ionicons 
            name={isMicMuted ? "mic-off-outline" : "mic-outline"} 
            size={24} 
            color="#fff" 
          />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.controlButton} onPress={toggleVideo}>
          <Ionicons 
            name={isVideoEnabled ? "videocam-outline" : "videocam-off-outline"} 
            size={24} 
            color="#fff" 
          />
        </TouchableOpacity>
        
        <TouchableOpacity style={[styles.controlButton, styles.endCallButton]} onPress={endCall}>
          <Ionicons name="call" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  loadingText: {
    color: '#fff',
    fontSize: 18,
  },
  camera: {
    flex: 1,
  },
  disabledCamera: {
    flex: 1,
    opacity: 0,
  },
  disabledVideoOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#222',
    justifyContent: 'center',
    alignItems: 'center',
  },
  disabledVideoText: {
    color: '#fff',
    fontSize: 16,
    marginTop: 10,
  },
  callInfoBar: {
    position: 'absolute',
    top: 40,
    left: 0,
    right: 0,
    padding: 15,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    alignItems: 'center',
  },
  calleeName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  callDuration: {
    color: '#ddd',
    fontSize: 14,
    marginTop: 5,
  },
  callStatus: {
    color: '#ddd',
    fontSize: 14,
    marginTop: 5,
  },
  controlsContainer: {
    position: 'absolute',
    bottom: 30,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    padding: 15,
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(50, 50, 50, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  endCallButton: {
    backgroundColor: '#FF3B30',
  },
});